/*
 #  This seemed like such a good idea at the time. :)
 */

#define MAIN
#include "pam_tally.c"

